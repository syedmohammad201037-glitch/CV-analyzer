# ResumeIQ · React + Vite

A modern client-side resume analyzer built with React, TypeScript and Vite. It compares resume text with a target job description using a local TF-IDF implementation, keyword overlap and a built-in skills vocabulary.

## Requirements
- Node.js 20 LTS recommended
- No API key, Python backend, GPU, or paid AI service required

## Start
```bash
npm install
npm run dev
```
Open the local URL printed by Vite (usually `http://localhost:5173`).

## Build
```bash
npm run build
npm run preview
```

## Included
- PDF, DOCX and TXT parsing in the browser
- Paste-text fallback
- Resume/job-description similarity score
- Detected matched skills and potential skill gaps
- Practical improvement checklist
- Downloadable CSV report
- Responsive black-and-white dashboard

## How it works
This is lightweight, explainable NLP rather than a generative LLM. It tokenizes the text, computes TF-IDF vectors and cosine similarity, and detects skills from a curated vocabulary. The score is a heuristic comparison aid, not a probability of being hired. Skill extraction may miss synonyms or unlisted terms. Scanned/image-only PDFs are not OCR processed.

## Privacy
Resume parsing and analysis happen in the browser. The PDF/DOCX libraries are downloaded as app dependencies during development/build; there are no resume uploads to a server in this project. Google Fonts are loaded from Google when online; remove the font links in `index.html` for a fully offline UI.
